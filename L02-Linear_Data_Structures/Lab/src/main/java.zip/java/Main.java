import implementations.Queue;
import interfaces.AbstractQueue;

public class Main {
    public static void main(String[] args) {

    }
}
