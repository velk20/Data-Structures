package barbershopjava;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
